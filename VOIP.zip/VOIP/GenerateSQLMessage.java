package ae.co.etisalat.cbcm.cmmn.soh.util;

import ae.co.etisalat.cbcm.app.soh.corporateusers.helper.CorporateUsersHelper;
import java.util.ArrayList;

public class GenerateSQLMessage 
{
  public GenerateSQLMessage()
  {
  }
  
  String generatedSQLMsg;
  
  long serviceID;
  long partyID;
  String dName;
  String userName;
  long areaCode;
  long accNumber;
  long actionID;
  long accountID;
  long productID;
  String partyName;
  long pGroupID;
  String msgTypeMap;
  String guidingID;
  String dCategoryForDeletion;
  String msgType;
  long regionID;
  String inetGroupID;
  long multiUserB1;
  public String getSQLMessage(ArrayList sqlDetails)
  {
  String tempServiceID = (String)sqlDetails.get(0);
  serviceID = Long.parseLong(tempServiceID);
  
  String tempPartyID = (String)sqlDetails.get(1);
  partyID = Long.parseLong(tempPartyID)  ;
  
  dName =  (String)sqlDetails.get(2);
  userName = (String)sqlDetails.get(3);
  
  String tempAreaCode = (String)sqlDetails.get(4);
  areaCode = Long.parseLong(tempAreaCode);
  
  String tempAccNumber = (String)sqlDetails.get(5);
  accNumber = Long.parseLong(tempAccNumber);
  
  String tempActionID = (String)sqlDetails.get(6);
  actionID = Long.parseLong(tempActionID);
  
  String tempAccountID = (String)sqlDetails.get(7);
  accountID = Long.parseLong(tempAccountID);
  
  String tempProductID = (String)sqlDetails.get(8);
  productID = Long.parseLong(tempProductID);
  
  partyName = (String)sqlDetails.get(9);
  
  String tempPGroupID = (String)sqlDetails.get(10);
  pGroupID = Long.parseLong(tempPGroupID);
  
  msgTypeMap = (String)sqlDetails.get(11);
  guidingID = (String)sqlDetails.get(12);
  dCategoryForDeletion = (String)sqlDetails.get(13);
  
  String  tempRegionID = (String)sqlDetails.get(14);
  regionID = Long.parseLong(tempRegionID);
  
  String  tempMultiUserB1 =(String)sqlDetails.get(15);
  multiUserB1 = Long.parseLong(tempMultiUserB1);
  
      if(regionID == 6)
    {
      regionID = 9;
    }
    else if(regionID== 4)
    {
      regionID = 6;
    }
    
    inetGroupID = "100"+regionID;
        
    if(serviceID == 14001)
            {
             areaCode = 942;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14001_DELETE')";
             actionID = 15;
             dName = null;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'E52+' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")";
            }else if (serviceID == 14002)
            {
            areaCode = 943;
            dName = null;
            msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'B52+' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")";
            actionID = 271;
            }else if (serviceID == 14004)
            {
            areaCode = 943;
            msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14004_DELETE')";
            actionID = 15;
            dName = null;
            msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'V54+' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")";
           }else if (serviceID == 15001)
            {
              areaCode = 949; 
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15001_DELETE')";
              actionID = 15;
              dName = "(SELECT DOMAIN_NAME FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID ="+accountID+") ";
                if(dName == null)
                {
                 dName = "emirates.net.ae";
                }
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'EM01-' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")";
            }else if (serviceID == 15007)
            {
              areaCode = 948;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15007_DELETE')";
              dName = "(SELECT DOMAIN_NAME FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID ="+accountID+") ";
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'SWH02-' )";
              userName = guidingID;
            }else if (serviceID == 15057)
            {
              areaCode = 960;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15057_DELETE')";
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'SYM02-' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")"; 
            }else if (serviceID == 14065)
            {
              areaCode = 945;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14065_DELETE')";
              dName = "(SELECT DOMAIN_NAME FROM T_SOH_ACCOUNT_DOMAIN_NAME WHERE ACCOUNT_ID ="+accountID+") ";
              actionID = 81;
            }else if (serviceID == 30955)
            {
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'B62+' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")"; 
              serviceID = 14002;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'BONE_14002_DELETE')";
              areaCode = 943;
              actionID = 272;
              dName = null;
              if(multiUserB1 == 1)
              {
               dName = "(SELECT DOMAIN_NAME FROM T_SOH_ACCOUNT_DOMAIN_NAME WHERE ACCOUNT_ID ="+accountID+") ";
              }
            }else if (serviceID == 14010)
            {
             areaCode = 947;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14010_DELETE')";
             actionID = 15;
             dName = null;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'D52+' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")"; 
            }else if (serviceID == 14011)
            {
             areaCode = 947;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14011_DELETE')";
             actionID = 15;
             dName = null;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'E62+' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")";
            }else if (serviceID == 14003)
            {
             areaCode = 943;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14001_DELETE')";
             actionID = 15;
             dName = null;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'V52+' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")";
            }else if (serviceID == 30956)
            {
              serviceID = 15001;
              areaCode = 949; 
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15001_DELETE')";
              actionID = 15;
              dName = "(SELECT DOMAIN_NAME FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID ="+accountID+") ";
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE MG, T_SOH_ACCOUNT ACT WHERE MG.MESSAGE_TYPE_CODE = 'EM01-' "
                      +" AND MG.Product_Group_Id = ACT.PRODUCT_GROUP_ID "
                      +" AND ACT.ACCOUNT_ID = "+accountID+")";
            }
            
if(serviceID == 14001 || serviceID == 14002 || serviceID == 15001 || serviceID == 14004 || serviceID == 14003 || serviceID == 14010 ||  serviceID == 14011 || serviceID == 30956)                              
        {            
      String  inserteMail  = "INSERT INTO T_MDI_ACCESS_EMAIL_MESSAGE (PARTY_ID,INPUT_DATE,"
                            +" REQUEST_NO,DOMAIN_NAME,MSG_CATEGORY,INET_USER_ID,"
                            +" SERVICE_ORDER_TYPE,AREA_CODE,PRODUCT_NO, BUNDLE_MSG_SEQUENCE_NO, "
                            +" ACTION,MSG_TYPE,APPLICATION_NAME,BRANCH_CODE,"
                            +" BUNDLE_TOTAL_MESSAGES, MSG_SERIAL_NO,"
                            +" PRODUCT,SERVICE,PARTY_NAME,PRODUCT_GROUP,"
                            +" INTERNAL_ACCT_NO,MESSAGE_ID,"
                            +" PARENT_MESSAGE_ID,PRIORITY_ID,"
                            +" TRANS_STR_ID,MESSAGE_GEN_RULE_ID,"
                            +" MESSAGE_SET_ID,MESSAGE_TYPE_MAP_ID,"
                            +" QUEUE_ID,BUNDLE_NO,MDI_STATUS_ID,"
                            +" DATE_SERVICE_REQUIRED,LINKED_TABLE_IDS,"
                            +" DELETION_STATUS,CREATED_USER_ID,"
                            +" CREATED_DATE,MODIFIED_USER_ID,"
                            +" MODIFIED_DATE,MESSAGE_SENT_DATE,ACCESS_EMAIL_SERVICE,INET_GROUP)"
                            +" values("+partyID+","
                            +" SYSTIMESTAMP,100, "+dName+", 'SN',"
                            +" '"+userName+"', 0, "+areaCode+", "+accNumber+", "
                            +" 0,"+actionID+","
                            +" "+msgType+","
                            +" 'CRS',"
                            +" (SELECT REGION_ID FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID = "+accountID+"),"
                            +" 1,SQ_CBCM_MDS_MSG_SERIAL_NO.NEXTVAL,"
                            +" "+productID+","+serviceID+",'"+partyName+"',"+pGroupID+","+accountID+","
                            +" SQ_MDI_ACCESS_EMAIL_MESSAGE.NEXTVAL,"
                            +" 0,1,200,150,0,"+msgTypeMap+",158,1,"
                            +" (SELECT MDI_STATUS_ID FROM T_MDI_MST_STATUS WHERE STATUS_CODE='MSGTOBESENT'),"
                            +" SYSTIMESTAMP,'0','N','D_USER_NAME',SYSTIMESTAMP,"
                            +" 'D_USER_NAME', SYSTIMESTAMP,SYSTIMESTAMP,"+serviceID+","+inetGroupID+")";
  
    
  generatedSQLMsg = inserteMail;
      
        }
        
       if(serviceID == 15057)
        {  
         
 String  inserteSymentec    = "INSERT INTO T_MDI_SYM_MESSAGE "
                              +" (REQUEST_NO,ACTION,MSG_TYPE, PARTY_ID,APPLICATION_NAME,PRIMARY_SERVICE,"
                              +" MSG_CATEGORY, INET_USER_ID,BRANCH_CODE, BUNDLE_TOTAL_MESSAGES, "
                              +" MSG_SERIAL_NO, PRODUCT, SERVICE, AREA_CODE, PRODUCT_NO, "
                              +" BUNDLE_MSG_SEQUENCE_NO, PARTY_NAME, PRODUCT_GROUP,"
                              +" INTERNAL_ACCT_NO, MESSAGE_ID, PARENT_MESSAGE_ID,"
                              +" PRIORITY_ID,TRANS_STR_ID, MESSAGE_GEN_RULE_ID,"
                              +" MESSAGE_SET_ID, MESSAGE_TYPE_MAP_ID,QUEUE_ID, BUNDLE_NO,"
                              +" MDI_STATUS_ID,DATE_SERVICE_REQUIRED, DELETION_STATUS, "
                              +" CREATED_USER_ID,CREATED_DATE,MODIFIED_USER_ID,MODIFIED_DATE,MESSAGE_SENT_DATE, "
                              +" SERVICE_ORDER_TYPE,INET_USER_NAME,REFERENCE_NO,ENVELOPE_NUMBER,PASSWORD,"
                              +" INPUT_DATE,FNR_INDICATOR,STATUS_CODE,NO_NAV_LICENSE,NO_NPF_LICENSE,NO_NIS_LICENSE,INET_GROUP)"
                              +"  VALUES (100, 15,"+msgType+","+partyID+",'CRS','"+serviceID+"', 'SN','"+userName+"',"
                              +" (SELECT REGION_ID FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID = "+accountID+"),1,SQ_CBCM_MDS_MSG_SERIAL_NO.NEXTVAL,"+productID+", "+serviceID+","+areaCode+","
                              +" "+accNumber+",1,'"+partyName+"',"+pGroupID+","+accountID+",SQ_MDI_SYM_MESSAGE.NEXTVAL,"
                              +" 0, 1,224,172,0,"+msgTypeMap+",182,1,"
                              +" (SELECT MDI_STATUS_ID FROM T_MDI_MST_STATUS WHERE STATUS_CODE='MSGTOBESENT')," 
                              +" CURRENT_TIMESTAMP, 'N',' D_USER_ID' ,CURRENT_TIMESTAMP ,  'D_USER_ID' ,"
                              +" CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,21,'"+partyName+"',0,"
                              +" 0,'5',CURRENT_TIMESTAMP,0,1,0,0,0,"+inetGroupID+")";
                              
      generatedSQLMsg = inserteSymentec;
      
        }
        
     if(serviceID == 15007)
        {   
                              
String  inserteSWH          = "INSERT INTO T_MDI_SWH_MESSAGE "
                              +" (REQUEST_NO,ACTION,MSG_TYPE, PARTY_ID,APPLICATION_NAME,PRIMARY_SERVICE,"
                              +" MSG_CATEGORY, INET_USER_ID,BRANCH_CODE, BUNDLE_TOTAL_MESSAGES, "
                              +" MSG_SERIAL_NO, PRODUCT, SERVICE, AREA_CODE, PRODUCT_NO, "
                              +" BUNDLE_MSG_SEQUENCE_NO, PARTY_NAME, PRODUCT_GROUP,"
                              +" INTERNAL_ACCT_NO, MESSAGE_ID, PARENT_MESSAGE_ID,"
                              +" PRIORITY_ID,TRANS_STR_ID, MESSAGE_GEN_RULE_ID,"
                              +" MESSAGE_SET_ID, MESSAGE_TYPE_MAP_ID,QUEUE_ID, BUNDLE_NO,"
                              +" MDI_STATUS_ID,DATE_SERVICE_REQUIRED, DELETION_STATUS, "
                              +" CREATED_USER_ID,CREATED_DATE,MODIFIED_USER_ID,MODIFIED_DATE,DOMAIN_NAME,MESSAGE_SENT_DATE"
                              +" ,INET_GROUP)"
                              +"  VALUES (100,15,"+msgType+","+partyID+",'CRS','"+serviceID+"', 'SN','"+userName+"',"
                              +" (SELECT REGION_ID FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID = "+accountID+"),1,SQ_CBCM_MDS_MSG_SERIAL_NO.NEXTVAL,"+productID+", "+serviceID+","+areaCode+","
                              +" "+accNumber+",1,'"+partyName+"',"+pGroupID+","+accountID+",SQ_MDI_SWH_MESSAGE.NEXTVAL,"
                              +" 0, 1,220,170,0,"+msgTypeMap+",178,1,"
                              +" (SELECT MDI_STATUS_ID FROM T_MDI_MST_STATUS WHERE STATUS_CODE='MSGTOBESENT')," 
                              +" CURRENT_TIMESTAMP, 'N',' D_USER_ID' ,CURRENT_TIMESTAMP ,  'D_USER_ID' ,"
                              +" CURRENT_TIMESTAMP,"+dName+",CURRENT_TIMESTAMP,"+inetGroupID+")";      
     
          generatedSQLMsg = inserteSWH;
        }
        
  if(serviceID == 14065)
        {        
   String  insertUAENIC       = "INSERT INTO T_MDI_UAE_NIC_MESSAGE("
                              +" MESSAGE_ID,MDI_STATUS_ID,TRANS_STR_ID,QUEUE_ID,PRIORITY_ID,MESSAGE_TYPE_MAP_ID,MESSAGE_GEN_RULE_ID,MESSAGE_SET_ID,"         
                              +" PARENT_MESSAGE_ID,BUNDLE_NO,DATE_SERVICE_REQUIRED,MESSAGE_SENT_DATE,ACTION,APPLICATION_NAME,AREA_CODE,"              
                              +" BRANCH_CODE,SERVICE,PARTY_ID,EXCH_CODE,PARTY_NAME,PRIMARY_SERVICE,PARTY_PASSWORD,INPUT_DATE,"             
                              +" INTERNAL_ACCT_NO,FNR_INDICATOR,MSG_CATEGORY,MSG_SERIAL_NO,MSG_TYPE,PARTY_ADDRESS,OPERATOR_ID,"            
                              +" PARTY_CITY,PARTY_COUNTRY_CODE,PRODUCT,PRODUCT_GROUP,PRODUCT_NO,REASON_CODE,REQUEST_NO,"                                             
                              +" SERVICE_ORDER_TYPE,STATUS_CODE,REFERENCE_NO,PARTY_POBOX,BUNDLE_TOTAL_MESSAGES,BUNDLE_MSG_SEQUENCE_NO,"                               
                              +" WORKORDER_REPRINT_CNT,PARTY_PHONE,PARTY_MOBILE,PARTY_FAX,PARTY_EMAIL,DOMAIN_NAME,SUB_DOMAIN_NAME,"
                              +" CREATE_DATE,EFFECTIVE_DATE,EXPIRY_DATE,RENEWAL_PERIOD,BUNDLED_FLAG,RESERVED_FLAG,"                                         
                              +" PRIMARY_DNS_NAME,PRIMARY_DNS_IP,SECONDARY_DNS_NAME,SECONDARY_DNS_IP,CONTACT_TYPE,CONTACT_NIC_HANDLER,"                            
                              +" CONTACT_NAME,CONTACT_CITY,CONTACT_ADDRESS,CONTACT_COUNTRY_CODE,CONTACT_POBOX,CONTACT_PHONE,CONTACT_MOBILE,"                                       
                              +" CONTACT_FAX,CONTACT_EMAIL,CREATED_USER_ID,CREATED_DATE,MODIFIED_USER_ID,MODIFIED_DATE,DELETION_STATUS,"
                              +" PARTY_ENVELOPE_NUMBER,LINKED_TABLE_IDS,INET_GROUP)"
                              +" values ("
                              +" SQ_MDI_UAE_NIC_MESSAGE.NEXTVAL,(SELECT MDI_STATUS_ID FROM T_MDI_MST_STATUS WHERE STATUS_CODE='MSGTOBESENT'),"
                              +" 224,182,1,"+msgTypeMap+",172,0,0,1,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,"+actionID+",'CRS',"+areaCode+","
                              +" (SELECT REGION_ID FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID = "+accountID+"),'"+serviceID+"',"+partyID+",'',"
                              +" '"+partyName+"',14042,0,CURRENT_TIMESTAMP,"+accountID+",0,'SN',SQ_CBCM_MDS_MSG_SERIAL_NO.NEXTVAL,910,'',"
                              +" '','','',"+productID+","+pGroupID+","+accNumber+",'',100,'',1,'',3838,0,0,0,'','','','',"+dName+","
                              +" '"+dCategoryForDeletion+"',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,0,0,0,'','',"
                              +" '','','','','','','','','','','','','','SYSTEM',CURRENT_TIMESTAMP,'SYSTEM',CURRENT_TIMESTAMP,'N','','',"+inetGroupID+")";
                              
           generatedSQLMsg = insertUAENIC;
        } 
        return generatedSQLMsg;
    }
  
   public String getSQLMessageForDomainNameNIC(ArrayList sqlDetails)
  {
  String tempServiceID = (String)sqlDetails.get(0);
  serviceID = Long.parseLong(tempServiceID);
  
  String tempPartyID = (String)sqlDetails.get(1);
  partyID = Long.parseLong(tempPartyID)  ;
  
  dName =  (String)sqlDetails.get(2);
  userName = (String)sqlDetails.get(3);
  
  String tempAreaCode = (String)sqlDetails.get(4);
  areaCode = Long.parseLong(tempAreaCode);
  
  String tempAccNumber = (String)sqlDetails.get(5);
  accNumber = Long.parseLong(tempAccNumber);
  
  String tempActionID = (String)sqlDetails.get(6);
  actionID = Long.parseLong(tempActionID);
  
  String tempAccountID = (String)sqlDetails.get(7);
  accountID = Long.parseLong(tempAccountID);
  
  String tempProductID = (String)sqlDetails.get(8);
  productID = Long.parseLong(tempProductID);
  
  partyName = (String)sqlDetails.get(9);
  
  String tempPGroupID = (String)sqlDetails.get(10);
  pGroupID = Long.parseLong(tempPGroupID);
  
  msgTypeMap = (String)sqlDetails.get(11);
  guidingID = (String)sqlDetails.get(12);
  dCategoryForDeletion = (String)sqlDetails.get(13);
  
  String  tempRegionID = (String)sqlDetails.get(14);
  regionID = Long.parseLong(tempRegionID);
  
  String  tempMultiUserB1 =(String)sqlDetails.get(15);
  multiUserB1 = Long.parseLong(tempMultiUserB1);
  
      if(regionID == 6)
    {
      regionID = 9;
    }
    else if(regionID== 4)
    {
      regionID = 6;
    }
    
    inetGroupID = "100"+regionID;


    if(serviceID == 14001)
            {
             areaCode = 942;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14001_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'E52+' )";
            }else if (serviceID == 14002)
            {
            areaCode = 943;
            msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'B52+' )";
            actionID = 271;
            }else if (serviceID == 14004)
            {
            areaCode = 943;
            msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14004_DELETE')";
            actionID = 15;
            msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'V54+' )";
            }else if (serviceID == 15001)
            {
              areaCode = 949; 
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15001_DELETE')";
              actionID = 15;
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'EM01-' )";
            }else if (serviceID == 15007)
            {
              areaCode = 948;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15007_DELETE')";
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'SWH02-' )";
              userName = guidingID;
            }else if (serviceID == 15057)
            {
              areaCode = 960;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15057_DELETE')";
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'SYM02-' )";
            }else if (serviceID == 14065)
            {
              areaCode = 945;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14065_DELETE')";
              actionID = 81;
            }else if (serviceID == 30955)
            {
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'B62+' )";
              serviceID = 14002;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'BONE_14002_DELETE')";
              areaCode = 943;
              actionID = 272;
            }else if (serviceID == 14010)
            {
             areaCode = 947;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14010_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'D52+' )";
            }else if (serviceID == 14011)
            {
             areaCode = 947;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14011_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'E62+' )";
            }else if (serviceID == 14003)
            {
             areaCode = 943;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14001_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'V52+' )";
            }else if (serviceID == 30956)
            {
              serviceID = 15001;
              areaCode = 949; 
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15001_DELETE')";
              actionID = 15;
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'EM01-' )";
            }
            
   String  insertUAENIC       = "INSERT INTO T_MDI_UAE_NIC_MESSAGE("
                              +" MESSAGE_ID,MDI_STATUS_ID,TRANS_STR_ID,QUEUE_ID,PRIORITY_ID,MESSAGE_TYPE_MAP_ID,MESSAGE_GEN_RULE_ID,MESSAGE_SET_ID,"         
                              +" PARENT_MESSAGE_ID,BUNDLE_NO,DATE_SERVICE_REQUIRED,MESSAGE_SENT_DATE,ACTION,APPLICATION_NAME,AREA_CODE,"              
                              +" BRANCH_CODE,SERVICE,PARTY_ID,EXCH_CODE,PARTY_NAME,PRIMARY_SERVICE,PARTY_PASSWORD,INPUT_DATE,"             
                              +" INTERNAL_ACCT_NO,FNR_INDICATOR,MSG_CATEGORY,MSG_SERIAL_NO,MSG_TYPE,PARTY_ADDRESS,OPERATOR_ID,"            
                              +" PARTY_CITY,PARTY_COUNTRY_CODE,PRODUCT,PRODUCT_GROUP,PRODUCT_NO,REASON_CODE,REQUEST_NO,"                                             
                              +" SERVICE_ORDER_TYPE,STATUS_CODE,REFERENCE_NO,PARTY_POBOX,BUNDLE_TOTAL_MESSAGES,BUNDLE_MSG_SEQUENCE_NO,"                               
                              +" WORKORDER_REPRINT_CNT,PARTY_PHONE,PARTY_MOBILE,PARTY_FAX,PARTY_EMAIL,DOMAIN_NAME,SUB_DOMAIN_NAME,"
                              +" CREATE_DATE,EFFECTIVE_DATE,EXPIRY_DATE,RENEWAL_PERIOD,BUNDLED_FLAG,RESERVED_FLAG,"                                         
                              +" PRIMARY_DNS_NAME,PRIMARY_DNS_IP,SECONDARY_DNS_NAME,SECONDARY_DNS_IP,CONTACT_TYPE,CONTACT_NIC_HANDLER,"                            
                              +" CONTACT_NAME,CONTACT_CITY,CONTACT_ADDRESS,CONTACT_COUNTRY_CODE,CONTACT_POBOX,CONTACT_PHONE,CONTACT_MOBILE,"                                       
                              +" CONTACT_FAX,CONTACT_EMAIL,CREATED_USER_ID,CREATED_DATE,MODIFIED_USER_ID,MODIFIED_DATE,DELETION_STATUS,"
                              +" PARTY_ENVELOPE_NUMBER,LINKED_TABLE_IDS,INET_GROUP)"
                              +" values ("
                              +" SQ_MDI_UAE_NIC_MESSAGE.NEXTVAL,(SELECT MDI_STATUS_ID FROM T_MDI_MST_STATUS WHERE STATUS_CODE='MSGTOBESENT'),"
                              +" 224,182,1,"+msgTypeMap+",172,0,0,1,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,"+actionID+",'CRS',"+areaCode+","
                              +" (SELECT REGION_ID FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID = "+accountID+"),'"+serviceID+"',"+partyID+",'',"
                              +" '"+partyName+"',14042,0,CURRENT_TIMESTAMP,"+accountID+",0,'SN',SQ_CBCM_MDS_MSG_SERIAL_NO.NEXTVAL,910,'',"
                              +" '','','',"+productID+","+pGroupID+","+accNumber+",'',100,'',1,'',3838,0,0,0,'','','','',"+" '"+dName+"',"
                              +" '"+dCategoryForDeletion+"',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,0,0,0,'','',"
                              +" '','','','','','','','','','','','','','SYSTEM',CURRENT_TIMESTAMP,'SYSTEM',CURRENT_TIMESTAMP,'N','','',"+inetGroupID+")";
                              
           generatedSQLMsg = insertUAENIC;
       
        return generatedSQLMsg;
    }
  
  
  
     public String getSQLMessageForDomainNameVE(ArrayList sqlDetails)
  {
  String tempServiceID = (String)sqlDetails.get(0);
  serviceID = Long.parseLong(tempServiceID);
  
  String tempPartyID = (String)sqlDetails.get(1);
  partyID = Long.parseLong(tempPartyID)  ;
  
  dName =  (String)sqlDetails.get(2);
  userName = (String)sqlDetails.get(3);
  
  String tempAreaCode = (String)sqlDetails.get(4);
  areaCode = Long.parseLong(tempAreaCode);
  
  String tempAccNumber = (String)sqlDetails.get(5);
  accNumber = Long.parseLong(tempAccNumber);
  
  String tempActionID = (String)sqlDetails.get(6);
  actionID = Long.parseLong(tempActionID);
  
  String tempAccountID = (String)sqlDetails.get(7);
  accountID = Long.parseLong(tempAccountID);
  
  String tempProductID = (String)sqlDetails.get(8);
  productID = Long.parseLong(tempProductID);
  
  partyName = (String)sqlDetails.get(9);
  
  String tempPGroupID = (String)sqlDetails.get(10);
  pGroupID = Long.parseLong(tempPGroupID);
  
  msgTypeMap = (String)sqlDetails.get(11);
  guidingID = (String)sqlDetails.get(12);
  dCategoryForDeletion = (String)sqlDetails.get(13);
  
  String  tempRegionID = (String)sqlDetails.get(14);
  regionID = Long.parseLong(tempRegionID);
  
  String  tempMultiUserB1 =(String)sqlDetails.get(15);
  multiUserB1 = Long.parseLong(tempMultiUserB1);
  
      if(regionID == 6)
    {
      regionID = 9;
    }
    else if(regionID== 4)
    {
      regionID = 6;
    }
    
    inetGroupID = "100"+regionID;
      
      if(serviceID == 14001)
            {
             areaCode = 942;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14001_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'E52+' )";
            }else if (serviceID == 14002)
            {
            areaCode = 943;
            msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'B52+' )";
            actionID = 271;
            }else if (serviceID == 14004)
            {
            areaCode = 943;
            msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14004_DELETE')";
            actionID = 15;
            msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'V54+' )";
            }else if (serviceID == 15001)
            {
              areaCode = 949; 
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15001_DELETE')";
              actionID = 15;
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'EM01-' )";
            }else if (serviceID == 15007)
            {
              areaCode = 948;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15007_DELETE')";
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'SWH02-' )";
              userName = guidingID;
            }else if (serviceID == 15057)
            {
              areaCode = 960;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15057_DELETE')";
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'SYM02-' )";
            }else if (serviceID == 14065)
            {
              areaCode = 945;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14065_DELETE')";
              actionID = 81;
            }else if (serviceID == 30955)
            {
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'B62+' )";
              serviceID = 14002;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'BONE_14002_DELETE')";
              areaCode = 943;
              actionID = 272;
            }else if (serviceID == 14010)
            {
             areaCode = 947;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14010_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'D52+' )";
            }else if (serviceID == 14011)
            {
             areaCode = 947;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14011_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'E62+' )";
            }else if (serviceID == 14003)
            {
             areaCode = 943;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14001_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'V52+' )";
            }else if (serviceID == 30956)
            {
              serviceID = 15001;
              areaCode = 949; 
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15001_DELETE')";
              actionID = 15;
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'EM01-' )";
            }
  
   String  inserteMail  = "INSERT INTO T_MDI_ACCESS_EMAIL_MESSAGE (PARTY_ID,INPUT_DATE,"
                            +" REQUEST_NO,DOMAIN_NAME,MSG_CATEGORY,INET_USER_ID,"
                            +" SERVICE_ORDER_TYPE,AREA_CODE,PRODUCT_NO, BUNDLE_MSG_SEQUENCE_NO, "
                            +" ACTION,MSG_TYPE,APPLICATION_NAME,BRANCH_CODE,"
                            +" BUNDLE_TOTAL_MESSAGES, MSG_SERIAL_NO,"
                            +" PRODUCT,SERVICE,PARTY_NAME,PRODUCT_GROUP,"
                            +" INTERNAL_ACCT_NO,MESSAGE_ID,"
                            +" PARENT_MESSAGE_ID,PRIORITY_ID,"
                            +" TRANS_STR_ID,MESSAGE_GEN_RULE_ID,"
                            +" MESSAGE_SET_ID,MESSAGE_TYPE_MAP_ID,"
                            +" QUEUE_ID,BUNDLE_NO,MDI_STATUS_ID,"
                            +" DATE_SERVICE_REQUIRED,LINKED_TABLE_IDS,"
                            +" DELETION_STATUS,CREATED_USER_ID,"
                            +" CREATED_DATE,MODIFIED_USER_ID,"
                            +" MODIFIED_DATE,MESSAGE_SENT_DATE,ACCESS_EMAIL_SERVICE,INET_GROUP)"
                            +" values("+partyID+","
                            +" SYSTIMESTAMP,100, '"+dName+"', 'SN',"
                            +" '"+userName+"', 0, "+areaCode+", "+accNumber+", "
                            +" 0,"+actionID+","
                            +" "+msgType+","
                            +" 'CRS',"
                            +" (SELECT REGION_ID FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID = "+accountID+"),"
                            +" 1,SQ_CBCM_MDS_MSG_SERIAL_NO.NEXTVAL,"
                            +" "+productID+","+serviceID+",'"+partyName+"',"+pGroupID+","+accountID+","
                            +" SQ_MDI_ACCESS_EMAIL_MESSAGE.NEXTVAL,"
                            +" 0,1,200,150,0,"+msgTypeMap+",158,1,"
                            +" (SELECT MDI_STATUS_ID FROM T_MDI_MST_STATUS WHERE STATUS_CODE='MSGTOBESENT'),"
                            +" SYSTIMESTAMP,'0','N','D_USER_NAME',SYSTIMESTAMP,"
                            +" 'D_USER_NAME', SYSTIMESTAMP,SYSTIMESTAMP,"+serviceID+","+inetGroupID+")";
  
    
  generatedSQLMsg = inserteMail;
      
       
        return generatedSQLMsg;
    }
  
  
  
     public String getSQLMessageForDomainNameSWH(ArrayList sqlDetails)
  {
  String tempServiceID = (String)sqlDetails.get(0);
  serviceID = Long.parseLong(tempServiceID);
  
  String tempPartyID = (String)sqlDetails.get(1);
  partyID = Long.parseLong(tempPartyID)  ;
  
  dName =  (String)sqlDetails.get(2);
  userName = (String)sqlDetails.get(3);
  
  String tempAreaCode = (String)sqlDetails.get(4);
  areaCode = Long.parseLong(tempAreaCode);
  
  String tempAccNumber = (String)sqlDetails.get(5);
  accNumber = Long.parseLong(tempAccNumber);
  
  String tempActionID = (String)sqlDetails.get(6);
  actionID = Long.parseLong(tempActionID);
  
  String tempAccountID = (String)sqlDetails.get(7);
  accountID = Long.parseLong(tempAccountID);
  
  String tempProductID = (String)sqlDetails.get(8);
  productID = Long.parseLong(tempProductID);
  
  partyName = (String)sqlDetails.get(9);
  
  String tempPGroupID = (String)sqlDetails.get(10);
  pGroupID = Long.parseLong(tempPGroupID);
  
  msgTypeMap = (String)sqlDetails.get(11);
  guidingID = (String)sqlDetails.get(12);
  dCategoryForDeletion = (String)sqlDetails.get(13);
  
  String  tempRegionID = (String)sqlDetails.get(14);
  regionID = Long.parseLong(tempRegionID);
  
  String  tempMultiUserB1 =(String)sqlDetails.get(15);
  multiUserB1 = Long.parseLong(tempMultiUserB1);
  
      if(regionID == 6)
    {
      regionID = 9;
    }
    else if(regionID== 4)
    {
      regionID = 6;
    }
    
    inetGroupID = "100"+regionID;
  
    if(serviceID == 14001)
            {
             areaCode = 942;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14001_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'E52+' )";
            }else if (serviceID == 14002)
            {
            areaCode = 943;
            msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'B52+' )";
            actionID = 271;
            }else if (serviceID == 14004)
            {
            areaCode = 943;
            msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14004_DELETE')";
            actionID = 15;
            msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'V54+' )";
            }else if (serviceID == 15001)
            {
              areaCode = 949; 
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15001_DELETE')";
              actionID = 15;
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'EM01-' )";
            }else if (serviceID == 15007)
            {
              areaCode = 948;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15007_DELETE')";
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'SWH02-' )";
              userName = guidingID;
            }else if (serviceID == 15057)
            {
              areaCode = 960;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15057_DELETE')";
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'SYM02-' )";
            }else if (serviceID == 14065)
            {
              areaCode = 945;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14065_DELETE')";
              actionID = 81;
            }else if (serviceID == 30955)
            {
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'B62+' )";
              serviceID = 14002;
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'BONE_14002_DELETE')";
              areaCode = 943;
              actionID = 272;
            }else if (serviceID == 14010)
            {
             areaCode = 947;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14010_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'D52+' )";
            }else if (serviceID == 14011)
            {
             areaCode = 947;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14011_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'E62+' )";
            }else if (serviceID == 14003)
            {
             areaCode = 943;
             msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_14001_DELETE')";
             actionID = 15;
             msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'V52+' )";
            }else if (serviceID == 30956)
            {
              serviceID = 15001;
              areaCode = 949; 
              msgTypeMap = "(select MESSAGE_TYPE_MAP_ID from T_MDI_MESSAGE_TYPE_MAP where MESSAGE_TYPE_MAP_CODE = 'CRS_15001_DELETE')";
              actionID = 15;
              msgType = "(SELECT MESSAGE_TYPE_ID FROM T_MDI_MST_MESSAGE_TYPE WHERE T_MDI_MST_MESSAGE_TYPE.MESSAGE_TYPE_CODE = 'EM01-' )";
            }
        String  inserteSWH          = "INSERT INTO T_MDI_SWH_MESSAGE "
                              +" (REQUEST_NO,ACTION,MSG_TYPE, PARTY_ID,APPLICATION_NAME,PRIMARY_SERVICE,"
                              +" MSG_CATEGORY, INET_USER_ID,BRANCH_CODE, BUNDLE_TOTAL_MESSAGES, "
                              +" MSG_SERIAL_NO, PRODUCT, SERVICE, AREA_CODE, PRODUCT_NO, "
                              +" BUNDLE_MSG_SEQUENCE_NO, PARTY_NAME, PRODUCT_GROUP,"
                              +" INTERNAL_ACCT_NO, MESSAGE_ID, PARENT_MESSAGE_ID,"
                              +" PRIORITY_ID,TRANS_STR_ID, MESSAGE_GEN_RULE_ID,"
                              +" MESSAGE_SET_ID, MESSAGE_TYPE_MAP_ID,QUEUE_ID, BUNDLE_NO,"
                              +" MDI_STATUS_ID,DATE_SERVICE_REQUIRED, DELETION_STATUS, "
                              +" CREATED_USER_ID,CREATED_DATE,MODIFIED_USER_ID,MODIFIED_DATE,DOMAIN_NAME,MESSAGE_SENT_DATE"
                              +" ,INET_GROUP)"
                              +"  VALUES (100,15,"+msgType+","+partyID+",'CRS','"+serviceID+"', 'SN','"+userName+"',"
                              +" (SELECT REGION_ID FROM T_SOH_ACCOUNT WHERE ACCOUNT_ID = "+accountID+"),1,SQ_CBCM_MDS_MSG_SERIAL_NO.NEXTVAL,"+productID+", "+serviceID+","+areaCode+","
                              +" "+accNumber+",1,'"+partyName+"',"+pGroupID+","+accountID+",SQ_MDI_SWH_MESSAGE.NEXTVAL,"
                              +" 0, 1,220,170,0,"+msgTypeMap+",178,1,"
                              +" (SELECT MDI_STATUS_ID FROM T_MDI_MST_STATUS WHERE STATUS_CODE='MSGTOBESENT')," 
                              +" CURRENT_TIMESTAMP, 'N',' D_USER_ID' ,CURRENT_TIMESTAMP ,  'D_USER_ID' ,"
                              +" CURRENT_TIMESTAMP,'"+dName+"',CURRENT_TIMESTAMP,"+inetGroupID+")";      
     
        generatedSQLMsg = inserteSWH;
       
        return generatedSQLMsg;
    }
  
  
  
}